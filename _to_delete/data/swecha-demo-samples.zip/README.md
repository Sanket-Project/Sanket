# Synthetic Swecha-style demo samples

Every sales quantity, stock value and SKU code here is synthetic. These files are for
software testing, not evidence about Swecha's business or achievable accuracy.
The public website informed product categories, extended sizing and store names.
Catalogue prices are examples; most prices are invented. See manifest.json.

## Tomorrow's local demo — 27 October 2026

1. Start Docker Desktop and wait for its engine to be ready.
2. Double-click Start_SANKET.bat in the repository root. Keep its console open.
   It checks the database revision and RLS, starts PostgreSQL + Redis, API,
   Chronos ML, forecast worker and frontend, then opens the local app.
3. Open http://127.0.0.1:5173 if the browser does not open automatically.
4. Workspace: `swecha-demo`; email: `demo@sanket.example.com`;
   password: `SanketDemo2026!`. These are local test credentials only.
5. Sign in. The dashboard uses an isolated workspace labelled SYNTHETIC Swecha Demo.
   This workspace already contains the sample catalogue, sales and stock.
6. To demonstrate upload, open Integrations > CSV/Excel. Import the files below,
   selecting their matching data type. For sales choose Daily or weekly totals
   (period identity) and INR. Re-uploading the same files adds no duplicate sales.
7. Open Forecasts. Twelve SKUs produce 12 weeks / 144 predictions from Chronos.
   The model uses uploaded sales history immediately; no per-client training job
   is needed to obtain this initial forecast.
8. Stop services with Ctrl+C in the launch console. PostgreSQL/Redis containers
   remain running with their data. Do not delete Docker volumes.

## Files and import order

- 00-products.csv — Products; 12 synthetic clothing SKUs with size and INR price.
- 01-steady-training.csv — Sales; 832 weekly store/SKU totals.
- 02-seasonal-training.csv — Sales; 832 weekly store/SKU totals.
- 03-intermittent-training.csv — Sales; 832 weekly store/SKU totals.
- 04-heldout-8-weeks.csv — Sales; 192 held-out observations, 31 Aug–19 Oct 2026.
- 05-inventory.csv — Inventory; 24 SKU/store stock positions.
- 06-invalid-example.csv — Sales; deliberately invalid date/negative quantity.
  Expect an explicit rejected row; never use this as valid sales.

Training files contain 104 weeks before 31 August 2026. The held-out file is used
only after a historical forecast cutoff is fixed. The prepared demo already has
it imported, and its latest forward forecast starts 26 October 2026.
For historical evaluation use Forecast Accuracy > backtest, cutoff 2026-08-31,
horizon 8 weeks; the service excludes later sales from that backtest's context.

## Using the client's real data

Use a separate client workspace; never mix real sales into this synthetic workspace.
CSV/Excel sales should identify SKU (including size/colour variant), date, quantity,
store/location and currency. Include selling price or revenue when available.
Use consistent dates such as YYYY-MM-DD. Export at least 8 observed weeks per SKU;
6–12 months is preferable, and seasonal products benefit from longer history.
If exporting transaction lines use transaction identity and order/line IDs; if
exporting daily/weekly totals choose period identity. Do not import the same
history once in each mode. Separate returns from nonnegative units sold.
New/unsold SKUs without enough history will need an explicit cold-start discussion.
Actual inventory, supplier lead times and costs are required for defensible order
recommendations; sales forecasts alone do not establish quantities to purchase.

## Evaluation limits

On this one synthetic eight-week test, WAPE was 18.03% overall, 7.89% steady,
20.84% seasonal and 97.53% intermittent. Lower is better; 97.53% is poor.
The four-week mean beat Chronos slightly on steady sales (7.15% vs 7.89%).
No routing rule or newly trained artifact was promoted. These stochastic results
are a diagnostic from this run, not a reproducible benchmark or client promise.

Chrome could not be controlled safely in this session; the website was reviewed
through indexed public pages. Live browser smoke testing remains unverified in
this session. React component tests and real API/service checks are recorded in
../../docs/audit/2026-10-26-demo-readiness/.
## Empty workspace for the client's own dataset

A second local workspace is prepared with no synthetic sales/catalogue/inventory:
workspace `swecha-client`, email `client@sanket.example.com`, password
`SanketClient2026!`. Sign out of the synthetic sample account and sign into this
workspace before uploading real client data. Both accounts are local test access,
with a 14-day local test entitlement; neither is a hosted production account.
This empty workspace will correctly show no-data states until a valid dataset is
imported. Upload the client's product catalogue and sales, then open Forecasts.
Do not upload these synthetic sample files into the client workspace.
